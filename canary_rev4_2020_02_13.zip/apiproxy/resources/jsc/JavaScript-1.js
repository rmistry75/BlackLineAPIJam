var count = context.getVariable("ratelimit.MyQuota.used.count");
if(count % 2 === 0)
{
    context.setVariable("GoTarget1", true);
}
else
{
    context.setVariable("GoTarget1", false);
}